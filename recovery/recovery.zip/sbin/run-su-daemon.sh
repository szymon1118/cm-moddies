#!/system/bin/sh
/system/xbin/su --daemon &
